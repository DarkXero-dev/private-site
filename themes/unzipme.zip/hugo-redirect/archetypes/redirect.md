+++
# For example, to Redirect from /old_blog to /blog, set 
# url to "/old_blog" and redirect_to to "/blog" below
type = "redirect"
url = ""
redirect_to = ""
redirect_enabled = true
private = true
+++