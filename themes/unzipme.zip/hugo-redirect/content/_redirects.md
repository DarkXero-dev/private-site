+++
url = "/_redirects"
outputs = ["redirects"]
draft = true
private = true
+++